#! /bin/bash
pdflatex AWBS.tex
bibtex AWBS
pdflatex AWBS.tex
pdflatex AWBS.tex
