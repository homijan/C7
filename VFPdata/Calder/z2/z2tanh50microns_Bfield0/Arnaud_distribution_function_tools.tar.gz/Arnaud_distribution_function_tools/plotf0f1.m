function [ output_args ] = plotf0f1( filename )
%PLOTF0F1 Summary of this function goes here
%   Detailed explanation goes here
M=load(filename);
% create the x and gamma grid, x is in unit of k0x so 2pi = 1 microns
qx=linspace(0,5902.4/(2*pi),1000); 
nr=linspace(1,1.04,500);
% bijection from gamma to v for f0 because I have f0(gamma) not f0(v) here
% v is normalized to c
for i=1:500
v(i)=sqrt(1-1/nr(i)^2);
end

for i=1:500 % over v
    for j=1:1000  %over x
       f(i,j)=M(1000*(i-1)+j);
          
    end
end
% define a thermal velocity to renormalized v
vT=sqrt(0.150/511.);
figure(1)
imagesc(qx(:),v(:)/vT,f(:,:));
set(gca,'Ydir','normal');


% to plot at 650 microns just take f(i,j=692) 

figure(2)
plot(v(:),f(:,292))
end

