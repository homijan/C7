function [ output_args ] = writefile( name,zc )
%WRITEFILE Summary of this function goes here
%   Detailed explanation goes here
ne=5e20;
nc=ne/0.448;
c=2.998e10;
me=9.11e-28;


Te=0.575-0.425*tanh((zc-450)/50)
vT=sqrt(Te/511)*c;
Af0=nc/c;
Af1=nc*me*c^2;
Af=1;
vT=1;
namefig=strcat(name,'.fig');
nametxt=strcat(name,'.txt');
openfig(namefig);
h=findobj('type','line','linestyle','--');
xr=get(h,'XData');
yr=get(h,'YData');
sizer=length(xr)
h=findobj('type','line','linestyle','-');
xb=get(h,'XData');
yb=get(h,'YData');
sizeb=length(xb)


save(name,'sizer','-ascii');

Mr=[xr(:)*vT,yr(:)*Af];

save(name,'Mr','-ascii','-append');
save(name,'sizeb','-ascii','-append');

Mb=[xb(:)*vT,yb(:)*Af];

save(name,'Mb','-ascii','-append');

figure(10)
plot(xb(:)*vT,yb(:)*Af);
hold on;
plot(xr(:)*vT,yr(:)*Af,'r--');

end

