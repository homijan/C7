function [ output_args ] = plotfile( name )
%PLOTFILE Summary of this function goes here
%   Detailed explanation goes here

fid=fopen(name,'r');
npic=fscanf(fid,'%e',[1])
fgetl(fid);

Mpic=fscanf(fid,'%e %e',[2 npic(1)]);
fgetl(fid);

nal=fscanf(fid,'%e',[1])
nal(1)
%fgetl(fid);
Mal=fscanf(fid,'%e %e',[2 nal(1)]);
%fgetl(fid);
figure(100)
plot(Mpic(1,:),Mpic(2,:));
hold on;
plot(Mal(1,:),Mal(2,:));
end

